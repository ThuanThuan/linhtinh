package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.NhanVien;
import model.bo.ManageBO;

/**
 * Servlet implementation class AddStaffServlet
 */
public class AddStaffServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddStaffServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ManageBO manageBO = new ManageBO();
		if("submit".equals(request.getParameter("submit"))){		//nhan nut Xac nhan o trang Them sinh vien
			String iD = request.getParameter("id");
			String fullName= request.getParameter("fullname");
			String age = request.getParameter("age");
			String address = request.getParameter("address");
			String phoneNumber = request.getParameter("phonenumber");
			String sex = request.getParameter("sex");
			String dePartMent = request.getParameter("department");
			manageBO.themNhanVien(iD, fullName, age, address, phoneNumber, sex, dePartMent);
			response.sendRedirect("ManageServlet");
		} else {													//chuyen sang trang Them sinh vien
			RequestDispatcher rd = request.getRequestDispatcher("addStaff.jsp");
			rd.forward(request, response);
		}
	}

}
