package model.bo;

import model.dao.CheckLoginDAO;

public class CheckLoginBO {
	
	public static boolean isValid(String userName, String passWord) {
		// TODO Auto-generated method stub
		CheckLoginDAO checkLoginDAO = new CheckLoginDAO();
		
		if("".equals(userName) || "".equals(passWord)){
			return false;
		}else
			return checkLoginDAO.isValid(userName,passWord);
	}

}
