package model.bo;

import java.util.ArrayList;

import model.bean.NhanVien;
import model.dao.ManageDAO;


public class ManageBO {
	static ManageDAO manageDAO = new ManageDAO();
	/*
	public ArrayList<NhanVien> getListNhanVien(String iD) {
		return manageDAO.getStaffList();
	}*/
	
	
	public ArrayList<NhanVien> getListNhanVien() {
		return manageDAO.getStaffList();
	}
	public static void themNhanVien(String iD, String fullName, String age, String address, String phoneNumber, String sex, String dePartMent) {
		manageDAO.themNhanVien(iD, fullName, age, address, phoneNumber, sex,dePartMent);
	}
	/*
	public SinhVien getThongTinSinhVien(String msv) {
		return sinhVienDAO.getThongTinSinhVien(msv);
	}
	
	public void suaSinhVien(String msv, String hoTen, String gioiTinh, String maKhoa) {
		sinhVienDAO.suaSinhVien(msv, hoTen, gioiTinh, maKhoa);
	}

	public void xoaSinhVien(String msv) {
		sinhVienDAO.xoaSinhVien(msv);
	}
	*/
}
