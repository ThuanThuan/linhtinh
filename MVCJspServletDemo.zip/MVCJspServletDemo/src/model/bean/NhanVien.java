package model.bean;

public class NhanVien {
	private String iD;
	private String fullName;
	private int age;
	private String address;
	private int phoneNumber;
	private String sex;
	private String dePartMent;
	
	/**
	 */
	
	public String getiD() {
		return iD;
	}
	public void setiD(String iD) {
		this.iD = iD;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getDePartMent() {
		return dePartMent;
	}
	public void setDePartMent(String dePartMent) {
		this.dePartMent = dePartMent;
	}
	
}
