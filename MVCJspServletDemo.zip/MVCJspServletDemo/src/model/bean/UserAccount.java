package model.bean;



public class UserAccount {
	private String userName;
	private String passWord;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	/*
	public boolean isValid() {
		
		Connection con = null;
		CallableStatement callstmt = null;
		Boolean loginState = false;
		ResultSet rs=null;
		try {
		DataAccess db = new DataAccess();
		con = db.getConnect();
		callstmt = con.prepareCall("{call CheckLogin(?,?)}");
		callstmt.setString(1, this.username.trim());
		callstmt.setString(2, this.pass.trim());
		rs = callstmt.executeQuery();
		while (rs.next()) {
		loginState = true;
		}
		} catch (Exception e) {
		System.out.println(e.getMessage());
		} finally {
		if (con != null) {
		try {
		con.close();
		} catch (Exception e) {
		System.out.println(e.getMessage());
		}
		}
		if (callstmt != null) {
		try {
			callstmt.close();
		} catch (Exception e) {
		System.out.println(e.getMessage());
		}
		}
		}
		return loginState;
		}
		*/
}
