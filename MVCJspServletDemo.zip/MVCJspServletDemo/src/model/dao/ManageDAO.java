package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.bean.NhanVien;

	public class ManageDAO {
	Connection con=null;
		
	public Connection Connect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;"
					+ "databaseName=DEMO; username=sa; password=12345678");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	
	public ArrayList<NhanVien> getStaffList() {
		Connect();
		String sql=	String.format("SELECT * FROM  NhanVien");
		ResultSet rs = null;
		try {
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<NhanVien> list = new ArrayList<NhanVien>();
		NhanVien nhanVien;
		try {
			while(rs.next()){
				nhanVien = new NhanVien();
				nhanVien.setiD(rs.getString("id"));
				nhanVien.setFullName(rs.getString("fullname"));
				nhanVien.setAge(rs.getInt("age"));
				nhanVien.setAddress(rs.getString("address"));
				nhanVien.setAge(rs.getInt("phonenumber"));
				nhanVien.setSex(rs.getString("sex"));
				nhanVien.setDePartMent(rs.getString("department"));
				list.add(nhanVien);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public void themNhanVien(String iD, String fullName, String age, String address, String phoneNumber, String sex,
			String dePartMent) {
		Connect();
		String sql=	String.format("INSERT INTO NhanVien(id,fullname,age,address,phonenumber,sex,department) "+
					" VALUES ( '%s',N'%s','%s',N'%s' ,'%s' ,N'%s' ,N'%s' )", iD, fullName, age, address, phoneNumber, sex, dePartMent);
		try {
			Statement stmt = con.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void suaSinhVien(String iD, String fullName, String age, String address, String phoneNumber, String sex,
			String dePartMent) {
		Connect();
		String sql=	String.format("UPDATE NhanVien "+
					" SET fullname = N'%s', age = %s, address = N'%s', phonenumber = '%s', sex=N'%s', department = N'%s' " +
					" WHERE id = '%s'", iD, fullName, age, address, phoneNumber, sex, dePartMent);
		try {
			Statement stmt = con.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void xoaSinhVien(String iD) {
		Connect();
		String sql=	String.format("DELETE FROM NhanVien WHERE id = '%s'", iD);
		try {
			Statement stmt = con.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
